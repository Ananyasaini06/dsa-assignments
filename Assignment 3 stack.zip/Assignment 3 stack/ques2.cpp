// #include <iostream>

// using namespace std;
// class String{
//     string str;
//     public:
//     void setstring(){
//         cout<<"enter a string:";
//         getline(cin,str);
//     }
//     void reversestring(){
//         int n=str.length();

//         char stack[100];
//         int top=-1;
// for(int i=0;i<n;i++){
//     stack[++top]=str[i];
// }

// cout<<"reversed string:";
// while(top>=0){
//     cout<<stack[top--];

// }
// cout<<endl;

//     }
// };

// int main() {
//     String sr;
//     sr.setstring();
//     sr.reversestring();

    
    
//     return 0;
// }

#include <iostream>

using namespace std;

class Stack{
    int capacity;
    int* arr;
    int top;
    public:
    Stack(int c){
        this->capacity=c;
        arr=new int[c];
        this->top=-1;
    }
    void push(int value){
        if(this->top==this->capacity-1){
            cout<<"overflow";
            return ;
        }
        this->top++;
        this->arr[this->top]=value;
  }
  void pop(){
    if(this->top==-1){
        cout<<"underflow";

    }
    this->top--;
  }
  int peek(){
    if(this->top==-1){
        cout<<"underflow";
        return INT16_MIN;
    }
    return this->arr[this->top];

  }
  bool isEmpty(){
    return this->top==-1;
  }
  bool isFull(){
    return this->top==this->capacity-1;
  }

};

int main() {
    Stack s(5);
    s.push(10);
    s.push(20);
    s.push(30);
   cout<<"top element:"<<s.peek()<<endl;
   s.push(40);
   cout<<"top element:"<<s.peek()<<endl;
   s.pop();
   cout<<"top element:"<<s.peek()<<endl;


    
    return 0;
}