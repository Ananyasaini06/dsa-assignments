#include<iostream>
using namespace std;

int main(){
int arr[100],n;

cout<<"enter no of elements:";
cin>>n;

cout<<"enter"<<n<<"elements:";
for(int i=0;i<n;i++)
    cin>>arr[i];

    int start=0,end=n-1;

    while(start<end){
        int temp=arr[start];
        arr[start]=arr[end];
        arr[end]=temp;
        start++;
        end--;
    }
    cout<<"array after reverse::";
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}
