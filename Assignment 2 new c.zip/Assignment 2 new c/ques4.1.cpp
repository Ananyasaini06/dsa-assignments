#include<iostream>
using namespace std;


int main(){

    string str1,str2;
    cout<<"enter your first name: ";
    cin>>str1;
    cout<<"enter your last name: ";
    cin>>str2;

    string result=str1+str2;
    cout<<"your full name is : "<<" "<<result<<endl;

    return 0;
}